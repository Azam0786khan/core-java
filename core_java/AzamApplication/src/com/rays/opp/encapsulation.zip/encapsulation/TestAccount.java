package com.rays.opp.encapsulation;

public class TestAccount {
	
	public static void main(String[] args) {
		
		Account a1=new Account();
		
		a1.setnumber("510000091156");
		System.out.println(a1.getnumber());
		a1.setType("saving");
		System.out.println(a1.getType());
		a1.setBalance(123.501);
		System.out.println(a1.getBalance());
		System.out.println("total balance = " + a1.getBalance());

		a1.deposit(1400.0);

		System.out.println("total balance after deposit = " + a1.getBalance());

		a1.withdraw(200.0);

		System.out.println("total balance = " + a1.getBalance());

	}
		
	}
	
