package com.rays.opp.encapsulation;

public class Person {
	
	private String firstName;
	private String lastName;
	private int age;
	private String address;

	public void setFirstName(String firstName) {
		this.firstName = firstName;

	}

	public String getFirstName() {
		return this.firstName;
	}
	
	public void setlastName(String lastName) {
		this.lastName=lastName;
		
	}
	public String getlastName() {
		return this.lastName;
		
	}
	public void setage(int age) {
		this.age=age;
	}
	public int getage() {
	return this.age;	
	}
	
	public void setaddress(String address) {
		this.address=address;
		}
	public String getaddress() {
		return this.address;
	}





}

