package com.rays.opp.encapsulation;

public class Account {

	private String number;
	private String type;
	private double balance;
	
	
	
	public void setnumber(String number) {
		this.number=number;
	}
	public String getnumber() {
		return this.number;
		
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public double deposit(double amount) {

		return this.balance = balance + amount;

	}

	public double withdraw(double amount) {

		if (amount > this.balance) {

			System.out.println("insufficient balance");

		} else {

			return this.balance = balance - amount;

		}

		return this.balance;

	}
	
	}

		
		
	
	
	
	
	

